--example 1  

DECLARE @Test INT = 1 

IF 1=2 
   SET  @Test = 2 
   SET  @Test = 3 

SELECT @Test 


GO 


-- Exmaple 2 

DECLARE @Test INT = 1 

IF 1=2 
BEGIN 
   SET  @Test = 2 
   SET  @Test = 3 
END 

SELECT @Test 


GO

