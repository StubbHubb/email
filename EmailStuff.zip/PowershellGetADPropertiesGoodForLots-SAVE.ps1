﻿get-aduser -server gcm.com -filter {(mail -like "sean.hayden@natwestmarkets.com" ) } -Properties samaccountname,enabled,mail, lastlogontimestamp
get-aduser -server fm.rbsgrp.net -filter {(mail -eq "sean.hayden@natwestmarkets.com" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid
get-aduser -server europa.rbsgrp.net -filter {(mail -eq "veronika.lunina@natwestmarkets.com" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid
get-aduser -server europa.rbsgrp.net -filter {(rbsemployeeid -eq "7919893" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid 

get-aduser -server rbsres01.net -filter {(mail -eq "patrick.tierney@rbs.com" ) } -Properties samaccountname,enabled,mail, lastlogontimestamp, proxyaddresses

get-aduser -server rbsres01.net -filter {(mail -eq "veronika.lunina@natwestmarkets.com" ) } -Properties samaccountname,enabled,mail, lastlogontimestamp, proxyaddresses | select -expandproperty proxyaddresses


get-aduser -server europa.rbsgrp.net -filter {(samaccountname -eq "ysyog" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid
get-aduser -server fm.rbsgrp.net -filter {(samaccountname -eq "cacrh" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid


get-aduser -server fm.rbsgrp.net -filter {(rbsemployeeid -eq "8025078" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, mail

 get-aduser hennmal -Properties mail


 get-aduser -server fm.rbsgrp.net -filter {(samaccountname -eq "liusiy" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid |export-csv -path h:\lookupFM.csv -append -force
get-aduser -server europa.rbsgrp.net -filter {(samaccountname -eq "liusiy" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid |export-csv -path h:\lookupEUROPA.csv -append -force
get-aduser -server gcm.com -filter {(samaccountname -eq "liusiy" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid |export-csv -path h:\lookupGCM.csv -append -force
get-aduser -server rbsres01.net -filter {(samaccountname -eq "haydens" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid |export-csv -path h:\lookupRBS.csv -append -force
get-aduser -server fm.rbsgrp.net -filter {(samaccountname -eq "rahiral" ) } -Properties  samaccountname,enabled,mail, lastlogontimestamp, rbsemployeeid |export-csv -path h:\lookupFM.csv -append -force